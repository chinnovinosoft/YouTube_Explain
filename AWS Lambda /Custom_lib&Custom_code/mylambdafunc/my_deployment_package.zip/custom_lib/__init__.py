__version__ = "1.0.0"
from .util import greet
__all__ = ["greet"]
